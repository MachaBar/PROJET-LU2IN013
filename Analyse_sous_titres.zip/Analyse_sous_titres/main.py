import os, glob
import re
import numpy as np
import math 
import matplotlib.pyplot as plt
import matplotlib.tri as tri 
from tempfile import TemporaryFile

from ouvertureFichiers import lecture_fichier,compterFichier
from creationMatrices import creationMatrice_X, matriceY, matrice_DistancesEucl, matrice_DistancesCos
from classification import classification, rechercheSerie, performance
from statistiques import histo

path = "/home/baranova/Bureau/L2/LU2IN013/series"

#tests ouverture fichier/creation dico



#tests creation et sauvegarde des matrices (faire des prints)
"""
print(creationMatrice_X(m))
print(matriceY())
print(matrice_DistancesEucl())

npzfile = np.load(sauvegarde_matrices())
print(npzfile['X']) #pour acceder a la matrice X
print(npzfile['DistEucl'])
"""

#tests classification
"""
print(classification(3,2,matrice_DistancesEucl()))
print(rechercheSerie(matriceY(),3,2,matrice_DistancesEucl()))
print(performance(2,3,matriceY(),matrice_DistancesEucl()))
"""

#tests statistiques
"""
print(histo(matrice_DistancesEucl()))
plt.imshow(matrice_DistancesEucl())
"""   
