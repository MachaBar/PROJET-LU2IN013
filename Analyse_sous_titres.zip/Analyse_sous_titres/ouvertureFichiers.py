import os, glob
import re
import numpy as np
import math 
import matplotlib.pyplot as plt
import matplotlib.tri as tri 


from tempfile import TemporaryFile

"""
def lecture_fichier(folder_path):
    s = []
    for dossname in glob.glob(os.path.join(folder_path, '*')):
        folder_path1 = dossname
        for filename in glob.glob(os.path.join(folder_path1, '*')):
            for episode in glob.glob(os.path.join(filename, '*.txt')):
                with open(episode, 'r' ) as f:
                    s.append(f.read())       
    return s

def compterFichier(folder_path): #compte le nombre de fichiers
    countFic = 0
    for dossname in glob.glob(os.path.join(folder_path, '*')):
        folder_path1 = dossname
        for filename in glob.glob(os.path.join(folder_path1, '*')):
            for episode in glob.glob(os.path.join(filename, '*.txt')):
                with open(episode, 'r' ) as f:
                    countFic = countFic + 1
                
    return countFic
"""    
def filtrageParMots(s):
    pattern = r'[a-zA-Z]+'
    listeMots = re.findall(pattern, s)
    return listeMots
    
def creationDico(m):
    Dico = dict()
    for s in m:
        listeMots = filtrageParMots(s)
        i = 0
        for mot in listeMots:
            if mot not in Dico:
                if len(mot)>=2:
                    Dico[mot] = i
                    i = i+1 
    return Dico

def compterFichier(folder_path): #compte le nombre de fichiers
    countFic = 0
    for dossname in glob.glob(os.path.join(folder_path, '*')):
        folder_path1 = dossname
        for filename in glob.glob(os.path.join(folder_path1, '*')):
            for episode in glob.glob(os.path.join(filename, '*.txt')):
                with open(episode, 'r' ) as f:
                    countFic = countFic + 1
               
    return countFic

def lecture_fichier(folder_path): #Renvoie T et Y

    T = []
    Y = np.zeros((compterFichier(folder_path),3)) #Probleme avec CountFic car nous en avons besoin pour creer la matrice du coup je l ai remis avant
    i = 0
    ep = 0
    sais = 0
    serie = 0

    for dossname in glob.glob(os.path.join(folder_path, '*')):
        serie = serie + 1
        folder_path1 = dossname
        for filename in glob.glob(os.path.join(folder_path1, '*')):
            sais = sais +1
            for episode in glob.glob(os.path.join(filename, '*.txt')):
                ep = ep + 1
                Y[i][0]= ep
                Y[i][1] = sais
                Y[i][2] = serie
                i = i+1
                with open(episode, 'r' ) as f:
                    T.append(f.read())
            ep = 0
        sais = 0

    return T, Y
