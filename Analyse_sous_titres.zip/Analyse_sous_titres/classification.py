import os, glob
import re
import numpy as np
import math 
import matplotlib.pyplot as plt
import matplotlib.tri as tri 
from tempfile import TemporaryFile

from ouvertureFichiers import lecture_fichier,compterFichier
from creationMatrices import creationMatrice_X, matriceY, matrice_DistancesEucl, matrice_DistancesCos

import sklearn
from sklearn.model_selection import train_test_split

def split ( X, Y):
    x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.25,shuffle=False)
    return x_train, x_test, y_train, y_test

def classification(k,ep,M,sais,ser): #ep correspond a la ligne/episode dans la matrice X (et M)
   listeDistances = [] #liste des k distances les plus petites de l'episode ep
   l = [] #liste des episodes se situant aux distances les plus petites de ep (les k plus proches episodes voisins)
   Y = matriceY()
   for i in range(0,len(Y)):#on cherche l'indice de la ligne qui correspond a l'episode de la serie et saison recherche
       if (Y[i][0] == ep) and (Y[i][1] == sais) and (Y[i][2] == ser):
           iep = i
   listeDistances = sorted(M[iep])
   listeDistances = listeDistances[1:k+1]
   for v in listeDistances:
        H = np.where( M[iep]== v)
        j = (H[0])[0]
        l.append(j)
   return l
   
#print(classification(3,2,matrice_DistancesEucl(),1,1))

#renvoie le numero de la serie qui correspondrai a l'episode recherche   
def rechercheSerie(Y,k,ep,M,sais,ser):#Y est la matrice Y indexee, M est la matrice des distances
    listeEp = classification(k,ep,M,sais,ser)
    listeSerie = []
    for i in listeEp:
        listeSerie.append(Y[i][2]) #dans la matrice Y le numero de la serie est situe dans la 3eme colonne  
    maxiOcc = 0 
    for k in listeSerie:
        if ( listeSerie.count(k) >= maxiOcc) :
            maxiOcc = listeSerie.count(k)
            maxi = k
    return maxi
#print(rechercheSerie(matriceY(),3,2,matrice_DistancesEucl(),1,1))
    
def performance(ep,k,Y,M,sais,ser):
    serieHypothese = rechercheSerie(Y,k,ep,M,sais,ser)
    #serieReel = Y[ep][2]
    serieReel = ser
    
    if (serieHypothese == serieReel):
        return True
    return False
    

#print(performance(2,3,matriceY(),matrice_DistancesEucl(),1,1))
