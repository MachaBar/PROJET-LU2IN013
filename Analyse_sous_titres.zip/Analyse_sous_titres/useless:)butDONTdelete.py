"""def worldCountEpisodes(ep,sais,ser):
    X = creationMatrice_X(lecture_fichier("/home/baranova/Bureau/L2/LU2IN013/series"))
    Y = matriceY()
    for i in range(0,len(Y)):#on cherche l'indice de la ligne qui correspond a l'episode de la serie et saison recherche
        if (Y[i][0] == ep) and (Y[i][1] == sais) and (Y[i][2] == ser):
            iep = i
    nbMax = X[iep].max()
    H = np.where(X[iep] == nbMax)
    j = (H[0])[0]#l'indice du mot qui apparait le plus souvent dans un episode
    mot = find_key(j,creationDico(lecture_fichier("/home/baranova/Bureau/L2/LU2IN013/series")) )#recherche du mot dans le dictionnaire
    return mot
    
def worldCountSaisons(sais,ser):
    X = creationMatrice_X(lecture_fichier("/home/baranova/Bureau/L2/LU2IN013/series"))
    Y = matriceY()
    L = []
    for i in range(0,len(Y)):#on cherche l'indice de la ligne qui correspond a l'episode de la serie et saison recherche
        if ((Y[i][1] == sais) and (Y[i][2] == ser)):
           L.append(i)
    maximum = 0
    for k in L :
        nbMax = X[k].max()
        if(nbMax >= maximum):
            maximum = nbMax
            iep = k
    H = np.where(X[iep] == maximum)
    j = (H[0])[0]#l'indice du mot qui apparait le plus souvent dans un episode
    mot = find_key(j,creationDico(lecture_fichier("/home/baranova/Bureau/L2/LU2IN013/series")) )#recherche du mot dans le dictionnaire
    return mot
#print(worldCountEpisodes(9,1,3))
#print(worldCountSaisons(2,1))  
    
def worldCountSeries(ser):
    X = creationMatrice_X(lecture_fichier("/home/baranova/Bureau/L2/LU2IN013/series"))
    Y = matriceY()
    L = []
    for i in range(0,len(Y)):#on cherche l'indice de la ligne qui correspond a l'episode de la serie et saison recherche
        if Y[i][2] == ser:
           L.append(i)
    maximum = 0
    for k in L :
        nbMax = X[k].max()
        if(nbMax >= maximum):
            maximum = nbMax
            iep = k
    H = np.where(X[iep] == maximum)
    print("max:",maximum)
    print("iep:",iep)
    print(H)
    j = (H[0])[0]#l'indice du mot qui apparait le plus souvent dans un episode
    mot = find_key(j,creationDico(lecture_fichier("/home/baranova/Bureau/L2/LU2IN013/series")) )#recherche du mot dans le dictionnaire
    return mot
#print(worldCountEpisodes(9,1,3))
print(worldCountSeries(3))  """
