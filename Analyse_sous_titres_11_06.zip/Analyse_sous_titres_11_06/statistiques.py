import os, glob
import re
import numpy as np
import math 
import matplotlib.pyplot as plt
import matplotlib.tri as tri 
from tempfile import TemporaryFile
from wordcloud import WordCloud, STOPWORDS
from PIL import Image


from ouvertureFichiers import lecture_fichier
from preprocessing import preprocessing, BoW, document_frequency, matriceX_Dico_processed
from creationMatricesDistances import matrice_DistancesEucl, matrice_DistancesEucl_version, matrice_DistancesCos_version, matrice_DistancesCos
from utilitaire import split
from perceptron import ajout_colonne_de1, labels, epoque2, cout_L, perceptron_epoque, perceptron, graphe, z_fonction, retrouveSerie, performance


def histo(M):
    plt.hist(np.reshape(M,len(M)*len(M),order='F'),bins=10,edgecolor = 'blue')
    plt.title('Histogramme des distances par rapport aux episodes')
    plt.xlabel('Distances')
    plt.ylabel('Nombre')
    plt.show()

def find_key(v,Dico):
    for k,val in Dico.items() :  
        if v == val:
            return k

def wordcloud(folder_path):
    
    mask = np.array(Image.open("cloud.png"))
    mask[mask == 1] = 255

    #text = open(episode, mode='r').read()
    liste_text, Y = lecture_fichier(folder_path)
    text = ""
    for c in liste_text:
        text = text + c
    wordcloud = WordCloud(background_color = 'white', stopwords = [] , max_words = 50, mask = mask).generate(text)
    plt.imshow(wordcloud)
    plt.axis("off")
    plt.show()

print(wordcloud("/home/baranova/Bureau/L2/LU2IN013/series"))

