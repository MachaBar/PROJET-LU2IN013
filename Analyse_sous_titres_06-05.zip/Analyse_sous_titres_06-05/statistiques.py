import os, glob
import re
import numpy as np
import math 
import matplotlib.pyplot as plt
import matplotlib.tri as tri 
from tempfile import TemporaryFile
from wordcloud import WordCloud, STOPWORDS
from PIL import Image


from ouvertureFichiers import lecture_fichier,compterFichier
from creationMatrices import creationMatrice_X, matriceY, matrice_DistancesEucl, matrice_DistancesCos
from classification import classification, rechercheSerie, performance

def histo(M):
    plt.hist(np.reshape(M,len(M)*len(M),order='F'),bins=10,edgecolor = 'blue')
    plt.title('Histogramme des distances par rapport aux episodes')
    plt.xlabel('Distances')
    plt.ylabel('Nombre')
    plt.show()

def find_key(v,Dico):
    for k,val in Dico.items() :  
        if v == val:
            return k

"""def wordcloud(episode):
    text = open(episode, mode='r').read()
    wordcloud = WordCloud(background_color = 'white', stopwords = [] , max_words = 50).generate(text)
    plt.imshow(wordcloud)
    plt.axis("off")
    plt.show()"""

#print(wordcloud('00__Unaired_Pilot.txt'))

def testPerformance():
    fichier = open("testPerformance.txt", "a")
    for k in range(3,5):
        for se in range (1,4):
            for sa in range(1,3):
                for ep in range(1, 4):
                    fichier.write(str(performance(k,ep,matriceY(),matrice_DistancesEucl(),sa,se)))
                    fichier.write('\n')
    fichier.close()

print(testPerformance())
#print(histo(matrice_DistancesEucl()))
#plt.imshow(matrice_DistancesEucl())
