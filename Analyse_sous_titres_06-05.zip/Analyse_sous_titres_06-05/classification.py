import os, glob
import re
import numpy as np
import math 
import matplotlib.pyplot as plt
import matplotlib.tri as tri 
from tempfile import TemporaryFile
from scipy.spatial import distance

from ouvertureFichiers import lecture_fichier
from creationMatrices import preprocessing, BoN, matrice_DistancesCos, document_frequency, matriceX_Dico_processed

import sklearn
from sklearn.model_selection import train_test_split

def split ( M, Y):
    m_train, m_test, y_train, y_test = train_test_split(M, Y, test_size=0.25,shuffle=False)
    return m_train, m_test, y_train, y_test


def kppv(M_train, Y_train, M_test,Y_test, k): # S'agit-il de X ou de M ?
    Y_chapeau = []
    print(M_test)
    for i in range(len(Y_test)):#on parcourt les episodes de la matrice Y_test
        listeDistances = [] #liste des k distances les plus petites de l'episode ep
        #print(M_test[i])
        listeDistances = M_test[i].argsort()
        #print(listeDistances)
        listeDistances = [ u for u in listeDistances if u!=i ] #on fait en sorte de pas compter l'episode lui meme
        listeDistances = [ j for j in listeDistances if j < len(M_train) ] #on choisit les episodes qui sont dans Y_train
        listeDistances = listeDistances[:k]
        #print(listeDistances)
        listeSerie = [Y_train[s][2] for s in listeDistances]
        #print(listeSerie)
        #Y_chapeau.append(max(set(listeSerie) , key = listeSerie.count ) )
        maxiOcc = 0 
        for k in listeSerie: #on cherche la serie la plus recurrente dans les k plus proches episodes
            if ( listeSerie.count(k) >= maxiOcc) :
                maxiOcc = listeSerie.count(k)
                maxi = k
        Y_chapeau.append(maxi)
    #print(Y_chapeau)
    return Y_chapeau
    
def performance(Y_test, Y_chapeau):#pourcentage de classement reussi
    count = 0
    for i in range(len(Y_chapeau)):
        #print(i,":",Y_chapeau[i],", ",Y_test[i][2])
        if (Y_chapeau[i] == Y_test[i][2]):
            count = count + 1
    return (count*100)/len(Y_chapeau)
 
T,Y = lecture_fichier("/home/baranova/Bureau/L2/LU2IN013/series")
X, dico = BoN(preprocessing(T))
X, dico = matriceX_Dico_processed(X, dico, document_frequency(X))
M = matrice_DistancesCos(X)
#M = scipy.spatial.distance.pdist(X, 'cosine')
m_train, m_test, y_train, y_test = split( M,Y) 
#print(y_train)
print(performance(y_test,kppv(m_train, y_train, m_test, y_test,100)))
